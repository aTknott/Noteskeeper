package com.example.alexdemonative.storage;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface NoteDao {

    @Query("SELECT * FROM noteEntity")
    List<NoteEntity> getAll();

    @Insert
    void insert(NoteEntity noteEntity);

    @Delete
    void delete(NoteEntity noteEntity);
}
