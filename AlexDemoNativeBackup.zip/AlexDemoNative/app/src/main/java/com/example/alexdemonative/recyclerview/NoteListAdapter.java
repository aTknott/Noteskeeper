package com.example.alexdemonative.recyclerview;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.alexdemonative.R;
import com.example.alexdemonative.storage.NoteEntity;

import java.util.List;

public class NoteListAdapter extends RecyclerView.Adapter<NoteListAdapter.NoteViewHolder> {

    private List<NoteEntity> noteList;

    public NoteListAdapter(List<NoteEntity> noteList){
        this.noteList = noteList;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.note_view, viewGroup, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder noteViewHolder, int i) {
        NoteEntity noteEntity = noteList.get(i);
        noteViewHolder.bodyView.setText(noteEntity.getBody());
        noteViewHolder.titleView.setText(noteEntity.getTitle());
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    static class NoteViewHolder extends RecyclerView.ViewHolder {

        private TextView titleView;
        private TextView bodyView;

        NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            this.titleView = itemView.findViewById(R.id.titleView);
            this.bodyView = itemView.findViewById(R.id.bodyView);
        }
    }
}
